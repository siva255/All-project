﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tax_calucation_app
{
  
  
        public class CalculationBy_Gender : Employee
        {

        public override double Tax_cal(string gender, double salary)
        {
            double tax = 0;

          

            if (gender == "Male")
            {
                if (salary < 250000)
                {
                    tax = 0;
                }
                else if (salary <= 250000 || salary < 500000)
                {
                    tax = salary * 0.05;
                }
                else if (salary >= 500000 || salary <= 1000000)
                {
                    tax = salary * 0.2;

                }
                else if (salary >= 1000000)
                {
                    tax = salary * 0.3;

                }
               
            }
            else
            {
                if (salary < 250000)
                {
                    tax = 0;
                }
                else if (salary <= 250000 || salary <= 500000)
                {
                    tax = salary * 0.05;

                }
                else if (salary <= 500000 || salary <= 1000000)
                {
                    tax = salary * 0.2;

                }
                else if (salary >= 1000000)
                {
                    tax = salary * 0.3;

                }
            }


            return tax;

        }

        
    }

    public class CalculationBy_Age : Employee
    {

        public override double Tax_cal(int Age, double salary)
        {
            double tax = 0;


                if (Age < 60)
                {
                if (salary < 250000)
                {
                    tax = 0;
                }
                else if (salary <= 250000 && salary <= 500000)
                {
                    tax = 0.05 * salary;
                }
                else if (salary <= 500000 && salary <= 1000000)
                {
                    tax = 0.2 * salary;

                }
                else if (salary >= 1000000)
                {
                    tax = 0.3 * salary;

                }
            }

            if (Age > 60 || Age < 80)
            {
                if (salary < 250000)
                {
                    tax = 0;
                }
                else if (salary <= 250000 && salary <= 500000)
                {
                    tax = 0.05 * salary;
                }
                else if (salary <= 500000 && salary <= 1000000)
                {
                    tax = 0.2 * salary;

                }
                else if (salary >= 1000000)
                {
                    tax = 0.3 * salary;

                }
            }
            if (Age > 80)
            {
                if (salary < 250000)
                {
                    tax = 0;
                }
                else if (salary <= 250000 && salary <= 500000)
                {
                    tax = 0.05 * salary;
                }
                else if (salary <= 500000 && salary <= 1000000)
                {
                    tax = 0.2 * salary;

                }
                else if (salary >= 1000000)
                {
                    tax = 0.3 * salary;

                }
            }




            return tax;

        }


    }

}

