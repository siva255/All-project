﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tax_calucation_app
{
   public class Employee
    {
        private int id;
        private string name;
        private string gender;
        private string dob;
        private int salary;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }
        public string DOB
        {
            get { return dob; }
            set { dob = value; }
        }
        public int Salary
        {
            get { return salary; }
            set { salary = value; }
        }


        public virtual double Tax_cal(string gender,double salary)
        {
            double tax = 0;

          

            
            return tax;


        }
        public virtual double Tax_cal(int Age, double salary)
        {
            double tax = 0;
            return tax;
        }
        }
}
