﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tax_calucation_app
{
 
    
        public static class FinderObject<T>
        {
            public static T FindDetails(List<dynamic> listofobject, string name)
            {
                T p = listofobject.Where(e => e.Name.ToLower() == name.ToLower()).FirstOrDefault();
                return p;
            }

      
        }
    }

