﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tax_calucation_app
{
    class Order
    {
        // Class member
        private string CounterName;

        // Constructor for Counter
        public Order(string Name)
        {
            CounterName = Name;
        }

        // Function that records the sales 
        //performed on the billing desk
        public bool Sales(Product prod, int howmuch)
        {
            return prod.RefillRequest(howmuch);
        }


        public void LowStockHandler(
          object Sender, EventArgs e,out string msg)
        {
            msg = string.Empty;
            string LowStockMessage =  string.Format ("Anouncement " + "on {0}: Stock of Product {1}" + " gone Low", CounterName,
                ((Product)Sender).ProductName);
            msg = LowStockMessage;
        }
    }
}
