﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tax_calucation_app
{
   public class Doctor
    {
        public Doctor(string name, string phone, int status)
        {
            Name = name;
            Phone = phone;
            Status = status;
        }

        public string Name { get; set; }

        public string Phone { get; set; }

        public int Status { get; set; }

      
    }
}
 