﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tax_calucation_app
{
  public  class Product
    {
        public int ItemId { get; set; }
        public string ProductName { get; set; }
        public string StockAnouncement { get; set; }
        public int Price { get; set; }
        public int StockInHand { get; set; }




        public delegate void OnStockLow(
          object sender, EventArgs e, out string msg);


        public event OnStockLow StockLow;


        public Product(int itemId, string Name, int price, int OpeningStock)
        {
            ItemId = ItemId;
            ProductName = Name;
            Price = price;
            StockInHand = OpeningStock;
        }


        public bool RefillRequest(int SalesDone)
        {
            StockInHand = StockInHand - SalesDone;
            bool isless5 = false;
            string stockMsg = string.Empty;
            if (StockInHand < 5)
            {

                EventArgs arg = new EventArgs();
                StockLow(this, arg, out stockMsg);
                isless5 = true;
                StockAnouncement = stockMsg;
            }                                                                
            return isless5;
        }
    }
}

