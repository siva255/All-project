﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tax_calucation_app
{
    public partial class Form1 : Form
    {
        Order order = null;
        Product product = null;
        public Form1()
        {
            InitializeComponent();
            order = new Order("counter1");
            product = new Product(1, "Mouse", 100, 7);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
            
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            string gender = comboBox1.Text;
            int salary = Convert.ToInt32(textBox6.Text);
            Employee emp = new CalculationBy_Gender();
            textBox2.Text = emp.Tax_cal(gender, salary).ToString();
        
      
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label16.Text = string.Empty;
            label17.Text = string.Empty;

            product.StockLow += new Product.OnStockLow(order.LowStockHandler);          
            bool checkorder_is_lessthan5 = order.Sales(product, Convert.ToInt32(textBox7.Text));
            label17.Text = product.StockAnouncement;
            label18.Text = "Qty : "+product.StockInHand.ToString();
            if (checkorder_is_lessthan5 == true)
            {
                label16.Text = "Order is placed! your available quantity is less than 5 for:" + product.ProductName;
            }
            else
            {
                label16.Text = "Thanks for Shopping Visit Again:" + product.ProductName;
            }
        }
            


        private void button6_Click(object sender, EventArgs e)
        {
            

            if(comboBox2.Text == "Doctor")
            {
                List<dynamic> doctors = new List<dynamic>();
                doctors.Add(new Doctor("Vishal", "7557035254", 1));
                doctors.Add(new Doctor("Bhrat", "9550352987", 0));
                doctors.Add(new Doctor("selvi", "8550352987", 1));
                Doctor d = FinderObject<Doctor>.FindDetails(doctors, textBox4.Text);
                if (d != null)
                    label15.Text = d.Name + "," + d.Phone + "," + d.Status;
                else
                    label15.Text = "Please Enter valid Doctor Name";

            }

            else
            {
                List<dynamic> patients = new List<dynamic>();
                patients.Add(new Patient("Siva", "1991", "7550352987", "pondicherry"));
                patients.Add(new Patient("Prakash", "1993", "7980352987", "Chennai"));
                patients.Add(new Patient("senthil", "1993", "7950352987", "Villpuram"));
                Patient p = FinderObject<Patient>.FindDetails(patients, textBox4.Text);

                if (p != null)
                label15.Text = p.Name + "," + p.Phone + "," + p.Address+","+p.DOB;

                else
                    label15.Text = "Please Enter  valid Patient Name ";


            }


        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label18.Text = "Qty : "+product.StockInHand.ToString();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            DateTime dob =Convert.ToDateTime(dateTimePicker1.Text);
            int year = (DateTime.Now.Year-dob.Year);
            double salary = Convert.ToDouble(textBox6.Text);
            Employee emp = new CalculationBy_Age();
            textBox2.Text = emp.Tax_cal(year, salary).ToString();

        }
    }
}
