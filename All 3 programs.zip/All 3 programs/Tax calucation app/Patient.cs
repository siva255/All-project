﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tax_calucation_app
{
    public class Patient
    {
        public Patient(string name, string dOB, string phone, string address)
        {
            Name = name;
            DOB = dOB;
            Phone = phone;
            Address = address;
        }
        
        public string Name { get; set; }

        public string DOB { get; set; }

        public string Phone { get; set; }


        public string Address { get; set; }


    }

}
